package com.example.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.fragment.app.Fragment;

import com.example.videoapp.LoginActivity;
import com.example.videoapp.R;
import com.example.videoapp.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MyFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MyFragment extends BaseFragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private Button logout;
    public LinearLayout linearLayout;
    private boolean bgflag = true;
    private RelativeLayout change_bg;

    public MyFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment MyFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MyFragment newInstance() {
        MyFragment fragment = new MyFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        logout = mRootView.findViewById(R.id.button_log_out);
//
//        return inflater.inflate(R.layout.fragment_my2, container, false);
//    }

    @Override
    protected int initLayout() {
        return R.layout.fragment_my2;
    }

    @Override
    protected void initView() {

        linearLayout = mRootView.findViewById(R.id.info_bg_ll);
        logout = mRootView.findViewById(R.id.button_log_out);
        change_bg = mRootView.findViewById(R.id.rl_skin);
    }

    @Override
    protected void initData() {
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeByKey("token");
                navigateToWithFlag(LoginActivity.class,
                        Intent.FLAG_ACTIVITY_CLEAR_TASK| Intent.FLAG_ACTIVITY_NEW_TASK);
            }
        });
        change_bg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bgflag){
                    linearLayout.setBackgroundResource(R.drawable.shape_my_info_bg2);
                    bgflag = false;
                } else {
                    linearLayout.setBackgroundResource(R.drawable.shape_my_info_bg);
                    bgflag = true;
                }
            }
        });
    }
}