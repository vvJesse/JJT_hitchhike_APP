package com.example.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.adapter.HomeAdapter;
import com.example.videoapp.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CircleFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CircleFragment extends BaseFragment {

    // TODO: Rename and change types of parameters
    private HomeAdapter homeAdapter;
    private ViewPager viewPager;

    public CircleFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static CircleFragment newInstance() {
        CircleFragment fragment = new CircleFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_circle, container, false);
    }

    @Override
    protected int initLayout() {
        return R.layout.fragment_circle;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}