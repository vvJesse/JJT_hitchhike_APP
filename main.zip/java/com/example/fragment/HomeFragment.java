package com.example.fragment;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.baidu.mapapi.CoordType;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.MapView;
import com.example.adapter.HomeAdapter;
import com.example.api.Api;
import com.example.api.ApiConfig;
import com.example.api.Callback;
import com.example.entity.CategoryEntity;
import com.example.entity.VideoCategoryResponse;
import com.example.videoapp.LoginActivity;
import com.example.videoapp.R;
import com.flyco.tablayout.SlidingTabLayout;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import util.StringUtils;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends BaseFragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
//    private static final String ARG_PARAM1 = "param1";
//    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private ArrayList<Fragment> mFragments = new ArrayList<>();
    private String[] mTitles;
    private HomeAdapter homeAdapter;
    private ViewPager viewPager;
    private SlidingTabLayout slidingTabLayout;
    private MapView mMapView;


    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance() {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected int initLayout() {
        SDKInitializer.initialize(this.getActivity().getApplicationContext());
        //自4.3.0起，百度地图SDK所有接口均支持百度坐标和国测局坐标，用此方法设置您使用的坐标类型.
        //包括BD09LL和GCJ02两种坐标，默认是BD09LL坐标。
        SDKInitializer.setCoordType(CoordType.BD09LL);
        return R.layout.fragment_home;
    }

    @Override
    protected void initView() {
        mMapView = (MapView) mRootView.findViewById(R.id.bmapView);
        viewPager = mRootView.findViewById(R.id.f_ViewPager);
        slidingTabLayout = mRootView.findViewById(R.id.slidingTabLayout);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    protected void initData() {
        getVideoCategoryList();
    }

    @Override
    public void onResume() {
        super.onResume();
        //在activity执行onResume时执行mMapView. onResume ()，实现地图生命周期管理
        mMapView.onResume();
    }
    @Override
    public void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView. onPause ()，实现地图生命周期管理
        mMapView.onPause();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        //在activity执行onDestroy时执行mMapView.onDestroy()，实现地图生命周期管理
        mMapView.onDestroy();
    }

    private void getVideoCategoryList(){
        String token = getStringFromSp("token");
        if(!StringUtils.isEmpty(token)){
            Map<String, Object> params = new LinkedHashMap<>();
            //HashMap<String,Object> params = new HashMap<>();
            params.put("token", token);
            Api.config(ApiConfig.VIDEO_CATEGORY_LIST, params).getRequest(getActivity(), new Callback() {
                @Override
                public void onSuccess(String res) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            VideoCategoryResponse response = new Gson().fromJson(res, VideoCategoryResponse.class);
                            if (response!=null && response.getCode()==0){
                                List<CategoryEntity> data = response.getPage().getList();
                                if(data!=null && data.size() > 0){
                                    mTitles = new String[data.size()];
                                    for(int i = 0; i < data.size(); i++){
                                        mTitles[i] = data.get(i).getCategoryName();
                                        mFragments.add(VideoFragment.newInstance(data.get(i).getCategoryId()));
                                    }
                                    homeAdapter = new HomeAdapter(getFragmentManager(), mTitles, mFragments);
                                    viewPager.setOffscreenPageLimit(mFragments.size());
                                    viewPager.setAdapter(homeAdapter);
                                    slidingTabLayout.setViewPager(viewPager);
                                }
                            }
                        }
                    });
                }

                @Override
                public void onFailure(Exception e) {

                }
            });
        }else{
            navigateTo(LoginActivity.class);
        }
    }
}