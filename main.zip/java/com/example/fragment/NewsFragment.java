package com.example.fragment;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Message;

import com.example.adapter.NewsAdapter;
import com.example.api.Api;
import com.example.api.ApiConfig;
import com.example.api.Callback;
import com.example.entity.NewsEntity;
import com.example.entity.NewsListResponse;
import com.example.videoapp.LoginActivity;
import com.example.videoapp.R;
import com.google.gson.Gson;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import util.StringUtils;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NewsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NewsFragment extends BaseFragment {

    private RecyclerView recyclerView;
    private RefreshLayout refreshLayout;
    LinearLayoutManager linearLayoutManager;
    private NewsAdapter newsAdapter;
    private List<NewsEntity> list = new ArrayList<>();

    private int pagenum = 1;

    public NewsFragment() {
        // Required empty public constructor
    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0:
                    newsAdapter.setData(list);
                    newsAdapter.notifyDataSetChanged();
                    break;
            }
        }
    };


    // TODO: Rename and change types and number of parameters
    public static NewsFragment newInstance() {
        NewsFragment fragment = new NewsFragment();
        return fragment;
    }

    @Override
    protected int initLayout() {
        return R.layout.fragment_news;
    }

    @Override
    protected void initView() {
        recyclerView = mRootView.findViewById(R.id.recycleView_new);
        refreshLayout = mRootView.findViewById(R.id.refresh_new);
    }

    @Override
    protected void initData() {
        linearLayoutManager = new LinearLayoutManager(getActivity());   //这里是fragment不是activity，得到的是homeactivity
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
//        for(int i = 0; i < 15; i++){
//            int type = i % 3 + 1;
//            NewsEntity newsEntity = new NewsEntity();
//            newsEntity.setType(type);
//            list.add(newsEntity);
//        }
        newsAdapter = new NewsAdapter(getActivity());
        newsAdapter.setData(list);
        recyclerView.setAdapter(newsAdapter);
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                //refreshlayout.finishRefresh(2000/*,false*/);//传入false表示刷新失败
                pagenum = 1;
                getNewsList(true);
            }
        });
        refreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(RefreshLayout refreshlayout) {
                //refreshlayout.finishLoadMore(2000/*,false*/);//传入false表示加载失败
                pagenum++;
                getNewsList(false);
            }
        });
        getNewsList(true);
    }

    private void getNewsList(boolean isRefresh){
        String token = getStringFromSp("token");
        if(!StringUtils.isEmpty(token)){
            Map<String, Object> params = new LinkedHashMap<>();
            //HashMap<String,Object> params = new HashMap<>();
            params.put("token", token);
            params.put("page", pagenum);
            params.put("limit", ApiConfig.PAGE_SIZE);

            Api.config(ApiConfig.NEWS_LIST, params).getRequest(getActivity(), new Callback() {
                @Override
                public void onSuccess(String res) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if(isRefresh){
                                refreshLayout.finishRefresh(true);
                            }else{
                                refreshLayout.finishLoadMore(true);
                            }
                            NewsListResponse response = new Gson().fromJson(res, NewsListResponse.class);
                            if (response!=null && response.getCode()==0){
                                List<NewsEntity> data = response.getPage().getList();
                                if(data!=null && data.size() > 0){
                                    if(isRefresh){
                                        list = data;
                                    }else {
                                        list.addAll(data);
                                    }
                                    mHandler.sendEmptyMessage(0);
                                }else {
                                    if(isRefresh){
                                        showToast("暂时无数据加载");
                                    }else{
                                        showToast("没有更多数据了");
                                    }
                                }
                            }
                        }
                    });

//                    showToastSync(res);
                }

                @Override
                public void onFailure(Exception e) {
                    if(isRefresh){
                        refreshLayout.finishRefresh(true);
                    }else {
                        refreshLayout.finishLoadMore(true);
                    }
                }
            });
        }else{
            navigateTo(LoginActivity.class);
        }
    }
}