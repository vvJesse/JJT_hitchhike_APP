package com.example.jsbridge;


public interface LvUJsBridge {
	
	public void send(String data);
	public void send(String data, com.example.jsbridge.CallBackFunction responseCallback);

}
