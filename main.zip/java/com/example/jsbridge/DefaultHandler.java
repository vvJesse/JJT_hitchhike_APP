package com.example.jsbridge;

public class DefaultHandler implements com.example.jsbridge.BridgeHandler {

	String TAG = "DefaultHandler";
	
	@Override
	public void handler(String data, com.example.jsbridge.CallBackFunction function) {
		if(function != null){
			function.onCallBack("DefaultHandler response data");
		}
	}

}
