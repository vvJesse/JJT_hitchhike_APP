package com.example.jsbridge;

public interface CallBackFunction {
	
	public void onCallBack(String data);

}
