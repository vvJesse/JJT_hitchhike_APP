package com.example.jsbridge;

public interface BridgeHandler {
	
	void handler(String data, CallBackFunction function);

}
