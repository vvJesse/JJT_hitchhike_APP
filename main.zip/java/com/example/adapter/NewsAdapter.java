package com.example.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.api.Api;
import com.example.api.ApiConfig;
import com.example.api.Callback;
import com.example.entity.BaseResponse;
import com.example.entity.NewsEntity;
import com.example.videoapp.R;
import com.example.view.CircleTransform;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.List;

/*
    作者：王锦诚
    功能：NewsAdapter 是 NewsFragment 的 Adapter。功能是:
    1. 为了实现导航栏根据 position 获取相应的 Fragment 和 title 提供接口。
    2. NewsFragment 中有三种资讯的布局。在 Adapter 中实现相应的 ViewHolder
    同时接收数据 data，将数据和布局绑定并在前端显示。
* */

public class NewsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private List<NewsEntity> data;

    public void setData(List<NewsEntity> data) {
        this.data = data;
    }

    public NewsAdapter(Context context){
        this.context = context;
    }

    public NewsAdapter(Context context, List<NewsEntity> dt){
        this.context = context;
        this.data = dt;
    }


    // 根据布局类型 viewType 绑定不同的布局，返回不同的 viewHolder
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View v = LayoutInflater.from(context).inflate(R.layout.item_video_layout, parent,false);
//        ViewHolder viewHolder = new ViewHolder(v);
        if(viewType == 1){
            View v = LayoutInflater.from(context).inflate(R.layout.news_item_one, parent,false);
            return new ViewHolderOne(v);
        }else if(viewType == 2){
            View v = LayoutInflater.from(context).inflate(R.layout.news_item_two, parent,false);
            return new ViewHolderTwo(v);
        }else {
            View v = LayoutInflater.from(context).inflate(R.layout.news_item_three, parent,false);
            return new ViewHolderThree(v);
        }
    }

    // 据布局类型 viewType 初始化 viewHolder 中不同的控件
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        int type = getItemViewType(position);
        NewsEntity newsEntity = data.get(position);
        if(type == 1){
            ViewHolderOne vh = (ViewHolderOne) holder;
            vh.title.setText(newsEntity.getNewsTitle());
            vh.author.setText(newsEntity.getAuthorName());
            vh.comment.setText(newsEntity.getCommentCount() + "评论 .");
            vh.time.setText(newsEntity.getReleaseDate());
            //vh.newsEntity = newsEntity;

            // 将图片转化为圆形
            Picasso.with(context)
                    .load(newsEntity.getHeaderUrl())
                    .transform(new CircleTransform())
                    .into(vh.header);

            // 产生图片的缩略图
            Picasso.with(context)
                    .load(newsEntity.getThumbEntities().get(0).getThumbUrl())
                    .into(vh.thumb);
        }else if(type == 2){
            ViewHolderTwo vh = (ViewHolderTwo) holder;
            vh.title.setText(newsEntity.getNewsTitle());
            vh.author.setText(newsEntity.getAuthorName());
            vh.comment.setText(newsEntity.getCommentCount() + "评论 .");
            vh.time.setText(newsEntity.getReleaseDate());
            //vh.newsEntity = newsEntity;

            // 将图片转化为圆形
            Picasso.with(context)
                    .load(newsEntity.getHeaderUrl())
                    .transform(new CircleTransform())
                    .into(vh.header);

            // 产生图片的缩略图
            Picasso.with(context)
                    .load(newsEntity.getThumbEntities().get(0).getThumbUrl())
                    .into(vh.pic1);
            Picasso.with(context)
                    .load(newsEntity.getThumbEntities().get(1).getThumbUrl())
                    .into(vh.pic2);
            Picasso.with(context)
                    .load(newsEntity.getThumbEntities().get(2).getThumbUrl())
                    .into(vh.pic3);
        } else {
            ViewHolderThree vh = (ViewHolderThree) holder;
            vh.title.setText(newsEntity.getNewsTitle());
            vh.author.setText(newsEntity.getAuthorName());
            vh.comment.setText(newsEntity.getCommentCount() + "评论 .");
            vh.time.setText(newsEntity.getReleaseDate());
            //vh.newsEntity = newsEntity;

            // 将图片转化为圆形
            Picasso.with(context)
                    .load(newsEntity.getHeaderUrl())
                    .transform(new CircleTransform())
                    .into(vh.header);

            // 产生图片的缩略图
            Picasso.with(context)
                    .load(newsEntity.getThumbEntities().get(0).getThumbUrl())
                    .into(vh.thumb);
        }
        //NewsEntity newsEntity = data.get(position);
    }

    @Override
    public int getItemCount() {
        if(data!=null&&data.size()>0)
            return data.size();
        else
            return 0;
    }

    public class ViewHolderOne extends RecyclerView.ViewHolder{
        private TextView title;
        private TextView author;
        private TextView comment;
        private TextView time;
        private ImageView header;
        private ImageView thumb;

        public ViewHolderOne(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            author = itemView.findViewById(R.id.author);
            comment = itemView.findViewById(R.id.comment);
            time = itemView.findViewById(R.id.time);
            header = itemView.findViewById(R.id.header);
            thumb = itemView.findViewById(R.id.thumb);
        }
    }
    public class ViewHolderTwo extends RecyclerView.ViewHolder{

        private TextView title;
        private TextView author;
        private TextView comment;
        private TextView time;
        private ImageView header;
        private ImageView pic1, pic2, pic3;
        private NewsEntity newsEntity;

        public ViewHolderTwo(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            author = itemView.findViewById(R.id.author);
            comment = itemView.findViewById(R.id.comment);
            time = itemView.findViewById(R.id.time);
            header = itemView.findViewById(R.id.header);
            pic1 = itemView.findViewById(R.id.pic1);
            pic2 = itemView.findViewById(R.id.pic2);
            pic3 = itemView.findViewById(R.id.pic3);
        }
    }
    public class ViewHolderThree extends RecyclerView.ViewHolder{

        private TextView title;
        private TextView author;
        private TextView comment;
        private TextView time;
        private ImageView header;
        private ImageView thumb;
        //private NewsEntity newsEntity;

        public ViewHolderThree(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            author = itemView.findViewById(R.id.author);
            comment = itemView.findViewById(R.id.comment);
            time = itemView.findViewById(R.id.time);
            header = itemView.findViewById(R.id.header);
            thumb = itemView.findViewById(R.id.thumb);
        }
    }


    // 返回布局的类型
    @Override
    public int getItemViewType(int position) {
        return data.get(position).getType();
    }

    private void updateCount(int vid, int type, boolean flag) {
        HashMap<String, Object> params = new HashMap<String, Object>();
        params.put("vid", vid);
        params.put("type", type);
        params.put("flag", flag);
        Api.config(ApiConfig.VIDEO_UPDATE_COUNT, params).postRequest(context, new Callback() {
            @Override
            public void onSuccess(final String res) {
                Log.e("onSuccess", res);
                Gson gson = new Gson();
                BaseResponse baseResponse = gson.fromJson(res, BaseResponse.class);
                if (baseResponse.getCode() == 0) {

                }
            }

            @Override
            public void onFailure(Exception e) {

            }
        });
    }
}

