package com.example.adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;

/*
    作者：王锦诚
    功能：MyPageAdapter 是 MyFragment 的 Adapter。功能是为了实现导航栏根据 position
    获取相应的 Fragment 和 title 提供接口。
* */

public class MyPageAdapter extends FragmentPagerAdapter {

    private String[] mTitle;
    private ArrayList<Fragment> mFragment;

    public MyPageAdapter(FragmentManager fm, String title[], ArrayList<Fragment> fragments) {
        super(fm);
        mTitle = title;
        mFragment = fragments;
    }

    @Override
    public int getCount() {
        return mFragment.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mTitle[position];
    }

    @Override
    public Fragment getItem(int position) {
        return mFragment.get(position);
    }
}