package com.example.videoapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.example.adapter.MyPageAdapter;
import com.example.entity.TabEntity;
import com.example.fragment.CircleFragment;
import com.example.fragment.CollectFragment;
import com.example.fragment.ContactFragment;
import com.example.fragment.HomeFragment;
import com.example.fragment.MyFragment;
import com.example.fragment.NewsFragment;
import com.example.fragment.dacheFragment;
import com.flyco.tablayout.CommonTabLayout;
import com.flyco.tablayout.listener.CustomTabEntity;
import com.flyco.tablayout.listener.OnTabSelectListener;

import java.util.ArrayList;

public class HomeActivity extends BaseActivity {

    private String[] mTitle = {"打车", "通勤圈", "通讯", "我的"};
    private int[] mIconUnselectIds = {R.mipmap.dache, R.mipmap.tongqinquan,
            R.mipmap.contact, R.mipmap.personal_info};
    private int[] mIconSelectIds = {R.mipmap.dache_selected, R.mipmap.tongqinquan_selected,
            R.mipmap.contact_selected, R.mipmap.personal_info_selected};
    private ArrayList<Fragment> mFragment = new ArrayList<>();
    private ArrayList<CustomTabEntity> mTabEntities = new ArrayList<>();
    private ViewPager viewPager;
    private CommonTabLayout commonTabLayout;

//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_home);
//        initView();
//        initLayout();
//        initData();
//
//    }

    @Override
    protected int initLayout(){
        return R.layout.activity_home;
    }

    @Override
    protected void initView() {
        viewPager = findViewById(R.id.viewpager);
        commonTabLayout = findViewById(R.id.commonTabLayout);
    }

    @Override
    protected void initData(){
        mFragment.add(dacheFragment.newInstance());
        mFragment.add(CircleFragment.newInstance());
        mFragment.add(ContactFragment.newInstance());
        mFragment.add(MyFragment.newInstance());
        for (int i = 0; i < mTitle.length; i++){
            mTabEntities.add(new TabEntity(mTitle[i], mIconSelectIds[i], mIconUnselectIds[i]));
        }

        commonTabLayout.setTabData(mTabEntities);
        commonTabLayout.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                viewPager.setCurrentItem(position);
            }

            @Override
            public void onTabReselect(int position) {
            }
        });
        viewPager.setOffscreenPageLimit(mFragment.size());
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                commonTabLayout.setCurrentTab(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        viewPager.setAdapter(new MyPageAdapter(getSupportFragmentManager(), mTitle, mFragment));
    }

}