package com.example.listener;

public interface OnItemClickListener {
    void onItemClick(int position);
}