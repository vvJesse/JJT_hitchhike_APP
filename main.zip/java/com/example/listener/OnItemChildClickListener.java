package com.example.listener;

public interface OnItemChildClickListener {
    void onItemChildClick(int position);
}
